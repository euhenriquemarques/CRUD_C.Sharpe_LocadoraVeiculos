package locacaoFrotas.DzVolve.Backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import locacaoFrotas.DzVolve.Backend.model.TelaEstoque;
import locacaoFrotas.DzVolve.Backend.repository.TelaEstoqueRepository;

@Controller
public class TelaEstoqueController {
	
	@Autowired
	TelaEstoqueRepository tr;
	

	@RequestMapping(value = "/estoque", method = RequestMethod.GET)
	public String init() {
		return "estoque/telaestoque";
	}
	
	@RequestMapping(value = "/estoque", method = RequestMethod.POST)
	public String salvar(@Valid TelaEstoque estoque, BindingResult result, RedirectAttributes attributes ) {
		tr.save(estoque);
		return "redirect:/estoque";
	}
	
	@RequestMapping("/estoque")
	public String deletar(@RequestBody @Valid TelaEstoque estoque) {
		tr.delete(estoque);
		return "redirect:/estoque";
	}
	//função abaixo busca a lista que tem disponivel no banco de dados
			@RequestMapping("/listarEstoqueSaida")
			public ModelAndView listarEstoqueSaida() {
				ModelAndView mv = new ModelAndView("relatorio/estoqueSaida");
				Iterable<TelaEstoque> estoque = tr.findAll();
				mv.addObject("estoque", estoque);
				return mv;
			}

}
