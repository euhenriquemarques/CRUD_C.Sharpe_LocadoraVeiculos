package locacaoFrotas.DzVolve.Backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import locacaoFrotas.DzVolve.Backend.model.LancamentoDivida;
import locacaoFrotas.DzVolve.Backend.repository.LancamentoDividaRepository;

@Controller
public class LancamentoDividaController {

	@Autowired
	LancamentoDividaRepository ldr;
	
	
	@RequestMapping(value = "/lancamentoDivida", method = RequestMethod.GET)
	public String init() {
		return "lancamento/lancamentodividas";
	}
	
	@RequestMapping(value = "/lancamentoDivida", method = RequestMethod.POST)
	public String salvar(@Valid LancamentoDivida lancamentoDivida, BindingResult result, RedirectAttributes attributes ) {
		ldr.save(lancamentoDivida);
		return "redirect:/lancamentoDivida";
	}	  
	 
	@RequestMapping("/lancamentoDivida")
	public String deletar(@RequestBody @Valid LancamentoDivida lancamentoDivida) {
		ldr.delete(lancamentoDivida);
		return "redirect:/lancamentoDivida"; 
	}
	
	//função abaixo busca a lista que tem disponivel no banco de dados
			@RequestMapping("/listarDividas")
			public ModelAndView listarCadastro() {
				ModelAndView mv = new ModelAndView("relatorio/dividas");
				Iterable<LancamentoDivida> lancamentoDivida = ldr.findAll();
				mv.addObject("dividas", lancamentoDivida);
				return mv; 
			}
}
