package locacaoFrotas.DzVolve.Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DzVolveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DzVolveApplication.class, args);
	}

}

