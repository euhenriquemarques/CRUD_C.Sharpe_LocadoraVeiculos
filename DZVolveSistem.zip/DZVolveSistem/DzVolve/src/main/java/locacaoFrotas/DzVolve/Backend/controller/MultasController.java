package locacaoFrotas.DzVolve.Backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import locacaoFrotas.DzVolve.Backend.model.Multas;
import locacaoFrotas.DzVolve.Backend.repository.MultasRepository;

@Controller
public class MultasController {

	@Autowired
	MultasRepository mr;
	

	@RequestMapping(value = "/multas", method = RequestMethod.GET)
	public String init() {
		return "multas/multas";
	}
	
	@RequestMapping(value = "/multas", method = RequestMethod.POST)
	public String salvar(@Valid Multas multas, BindingResult result, RedirectAttributes attributes ) {
		mr.save(multas);
		return "redirect:/multas";
	}
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public ModelAndView editarMultas(@PathVariable("id") long id) {
		Multas multas = mr.findById(id);	
		ModelAndView mv = new ModelAndView("editar/multas");
		mv.addObject("multas", multas);
		return mv; 
	}	
	//função abaixo busca a lista que tem disponivel no banco de dados
		@RequestMapping("/listarMultas")
		public ModelAndView listarMultas() {
			ModelAndView mv = new ModelAndView("relatorio/multas");
			Iterable<Multas> multas = mr.findAll();
			mv.addObject("multas", multas);
			return mv;
		}
		@RequestMapping("/deletarMultas")
		public String deletarMultas(long id) {
			Multas multas = mr.findById(id);
			mr.delete(multas);
			return "redirect:/multas";
		}
	
	@RequestMapping("/multas")
	public String deletar(@RequestBody @Valid Multas multas) {
		mr.delete(multas);
		return "redirect:/multas";
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.POST)
	public String salvarEdicao(@PathVariable("id") long id, 
			@Valid Multas multas, @Valid String placa, 
			@Valid String cpf, @Valid String dataMulta, 
			@Valid double valorMulta, BindingResult result, RedirectAttributes attributes) {


		multas = mr.findById(id);
		multas.setPlaca(placa);
		multas.setCpf(cpf);
		multas.setDataMulta(dataMulta);
		multas.setValorMulta(valorMulta);
			mr.save(multas);
			return "relatorio/multas";
			
	


	}
	
	
}
