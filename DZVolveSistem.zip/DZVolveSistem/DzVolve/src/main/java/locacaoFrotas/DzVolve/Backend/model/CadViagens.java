package locacaoFrotas.DzVolve.Backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
public class CadViagens {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@NotEmpty
	private String modelo;
	@NotNull 
	private double kmInicial;
	@NotNull
	private boolean tanqueCheio;
	@NotNull 
	private String dataRetirada;
	@NotNull
	private String placaVeic;
	@NotNull
	private String dataEntrega;
	private boolean viagemComSeguro;
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getModelo() { 
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getKmInicial() {
		return kmInicial;
	}

	public void setKmInicial(double kmInicial) {
		this.kmInicial = kmInicial;
	}

	public boolean isTanqueCheio() {
		return tanqueCheio;
	}

	public void setTanqueCheio(boolean tanqueCheio) {
		this.tanqueCheio = tanqueCheio;
	}

	public String getDataRetirada() {
		return dataRetirada;
	}

	public void setDataRetirada(String dataRetirada) {
		this.dataRetirada = dataRetirada;
	}

	public String getPlacaVeic() {
		return placaVeic;
	}

	public void setPlacaVeic(String placaVeic) {
		this.placaVeic = placaVeic;
	}

	public String getDataEntrega() {
		return dataEntrega;
	}

	public void setDataEntrega(String dataEntrega) {
		this.dataEntrega = dataEntrega;
	}

	public boolean isViagemComSeguro() {
		return viagemComSeguro;
	}

	public void setViagemComSeguro(boolean viagemComSeguro) {
		this.viagemComSeguro = viagemComSeguro;
	}

}
