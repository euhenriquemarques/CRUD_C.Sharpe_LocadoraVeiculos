package locacaoFrotas.DzVolve.Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import locacaoFrotas.DzVolve.Backend.model.EntradaEstoque;

public interface EntradaEstoqueRepository extends JpaRepository<EntradaEstoque, Long>{
	
	EntradaEstoque findById(long id);

}
