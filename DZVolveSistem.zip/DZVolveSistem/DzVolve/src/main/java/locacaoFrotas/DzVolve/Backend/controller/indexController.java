package locacaoFrotas.DzVolve.Backend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class indexController {

	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public String form(String login, String pass,  RedirectAttributes attributes) {

		if (login.equals("dzvolve@dzvolve.com")  && pass.equals("123")) {
		
			return "login/menu";
		}
	
		attributes.addFlashAttribute("mensagem", "Login/Senha Incorreto");
		return "redirect:/";
	}

}
