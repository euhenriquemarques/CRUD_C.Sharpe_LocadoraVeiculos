package locacaoFrotas.DzVolve.Backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import locacaoFrotas.DzVolve.Backend.model.Garagem;
import locacaoFrotas.DzVolve.Backend.repository.GaragemRepository;

@Controller
public class GaragemController {
	
	@RequestMapping(value = "/garagem", method = RequestMethod.GET)
	public String init() {
		return "cadastro/cadastrodegaragens";
	}

	@Autowired
	GaragemRepository gr;
	

	
	@RequestMapping(value = "/garagem", method = RequestMethod.POST)
	public String salvar(@Valid Garagem garagem, BindingResult result, RedirectAttributes attributes ) {
		gr.save(garagem);
		return "redirect:/garagem"; 
	}
	
	@RequestMapping("/garagem")
	public String deletar(@RequestBody @Valid Garagem garagem) {
		gr.delete(garagem);
		return "redirect:/garagem";
	}
	//função abaixo busca a lista que tem disponivel no banco de dados
	@RequestMapping("/listarGaragens")
	public ModelAndView listarGaragens() {
		ModelAndView mv = new ModelAndView("relatorio/garagem");
		Iterable<Garagem> garagem = gr.findAll();
		mv.addObject("garagens", garagem);
		return mv;
	}
}
