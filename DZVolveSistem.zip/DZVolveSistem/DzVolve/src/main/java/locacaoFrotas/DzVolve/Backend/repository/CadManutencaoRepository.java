package locacaoFrotas.DzVolve.Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import locacaoFrotas.DzVolve.Backend.model.CadManutencao;

public interface CadManutencaoRepository extends JpaRepository<CadManutencao, Long> {

	CadManutencao findById(long id);

}
