package locacaoFrotas.DzVolve.Backend.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class Veiculo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@NotNull
	private String marca;
	@NotNull
	private String modelo;
	@NotNull
	private int ano;
	@NotNull
	private String placa;
	@NotNull
	private String cor;
	@NotNull
	private int renavam;
	@NotNull
	private boolean veiculoNovo;
	@NotNull
	private double kmAtual;
	@NotNull
	private boolean manutençãoEmDia;
	@NotNull
	private String uf;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public int getRenavam() {
		return renavam;
	}
	public void setRenavam(int renavam) {
		this.renavam = renavam;
	}
	public boolean isVeiculoNovo() {
		return veiculoNovo;
	}
	public void setVeiculoNovo(boolean veiculoNovo) {
		this.veiculoNovo = veiculoNovo;
	}
	public double getKmAtual() {
		return kmAtual;
	}
	public void setKmAtual(double kmAtual) {
		this.kmAtual = kmAtual;
	}
	public boolean isManutençãoEmDia() {
		return manutençãoEmDia;
	}
	public void setManutençãoEmDia(boolean manutençãoEmDia) {
		this.manutençãoEmDia = manutençãoEmDia;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	

}
