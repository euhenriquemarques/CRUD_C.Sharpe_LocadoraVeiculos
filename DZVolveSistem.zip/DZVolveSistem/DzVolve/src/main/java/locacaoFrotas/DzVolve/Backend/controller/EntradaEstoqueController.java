package locacaoFrotas.DzVolve.Backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import locacaoFrotas.DzVolve.Backend.model.EntradaEstoque;
import locacaoFrotas.DzVolve.Backend.repository.EntradaEstoqueRepository;

@Controller
public class EntradaEstoqueController {
	
	@RequestMapping(value = "/entradaEstoque", method = RequestMethod.GET)
	public String init() {
		return "estoque/estoqueentrada";
	}

	@Autowired
	EntradaEstoqueRepository esr;
	
	@RequestMapping(value = "/entradaEstoque", method = RequestMethod.POST)
	public String salvar(@Valid EntradaEstoque entradaEstoque, BindingResult result, RedirectAttributes attributes ) {
		esr.save(entradaEstoque);
		return "redirect:/entradaEstoque";
	}
	
	
	@RequestMapping("/entradaEstoque")
	public String deletar(@RequestBody @Valid EntradaEstoque entradaEstoque) {
		esr.delete(entradaEstoque);
		return "redirect:/entradaEstoque";
	}
	
	//função abaixo busca a lista que tem disponivel no banco de dados
			@RequestMapping("/listarEstoqueEntrada")
			public ModelAndView listaEstoqueEntrada() {
				ModelAndView mv = new ModelAndView("relatorio/estoqueEntrada");
				Iterable<EntradaEstoque> entradaEstoque = esr.findAll();
				mv.addObject("entradaEstoque", entradaEstoque);
				return mv;
			}
	
	
}
