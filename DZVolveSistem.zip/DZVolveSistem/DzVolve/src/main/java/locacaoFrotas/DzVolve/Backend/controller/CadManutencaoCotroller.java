package locacaoFrotas.DzVolve.Backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import locacaoFrotas.DzVolve.Backend.model.CadManutencao;
import locacaoFrotas.DzVolve.Backend.repository.CadManutencaoRepository;

@Controller
public class CadManutencaoCotroller {
	
	
	@RequestMapping(value = "/manutencao", method = RequestMethod.GET)
	public String init() {
		return "manutencao/telamanutencoes";
	}
	
	@Autowired
	CadManutencaoRepository cmr;
	
	@RequestMapping(path = "/manutencao", method = RequestMethod.POST)
	public String salvar(@Valid CadManutencao cadManutencao, BindingResult result, RedirectAttributes attributes ) {
		cmr.save(cadManutencao);
		return "redirect:/manutencao";
	}
	
	@RequestMapping("/deletarCadastro")
	public String delete(@RequestBody @Valid CadManutencao cadManutencao) {
		cmr.delete(cadManutencao);
		return "redirect:/manutencao"; 
	}
	//função abaixo busca a lista que tem disponivel no banco de dados
			@RequestMapping("/listarManutencao")
			public ModelAndView listarManutencao() {
				ModelAndView mv = new ModelAndView("relatorio/manutencao"); 
				Iterable<CadManutencao> cadManutencao = cmr.findAll();
				mv.addObject("cadManutencao", cadManutencao);
				return mv;
			}
			

}
