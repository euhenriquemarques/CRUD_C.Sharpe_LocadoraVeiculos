package locacaoFrotas.DzVolve.Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import locacaoFrotas.DzVolve.Backend.model.Multas;

public interface MultasRepository extends JpaRepository<Multas, Long>{
	
	Multas findById(long id);

}
