package locacaoFrotas.DzVolve.Backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import locacaoFrotas.DzVolve.Backend.model.CadViagens;

public interface CadViagensRepository extends JpaRepository<CadViagens, Long>{

	CadViagens findById(long id);
}
